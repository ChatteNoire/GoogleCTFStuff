package com.google.ctf.shallweplayagame;

class C0644N {
    static final int[] f2334a = new int[]{0, 1, 0};
    static final int[] f2335b = new int[]{1, 0, 2};
    static final int[] f2336c = new int[]{2, 0, 1};
    static final int[] f2337d = new int[]{3, 0, 0};
    static final int[] f2338e = new int[]{4, 1, 0};
    static final int[] f2339f = new int[]{5, 0, 1};
    static final int[] f2340g = new int[]{6, 0, 0};
    static final int[] f2341h = new int[]{7, 0, 2};
    static final int[] f2342i = new int[]{8, 0, 1};

    static {
        System.loadLibrary("rary");
    }

    static native Object m3217_(Object... objArr);
}
