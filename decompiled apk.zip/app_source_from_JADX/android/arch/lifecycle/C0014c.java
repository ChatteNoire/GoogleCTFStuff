package android.arch.lifecycle;

public interface C0014c {
    C0013b mo39a();
}
