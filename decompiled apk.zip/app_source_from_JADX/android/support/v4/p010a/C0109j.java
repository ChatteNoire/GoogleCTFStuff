package android.support.v4.p010a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class C0109j {
    public C0114h mo41a(Context context, String str, Bundle bundle) {
        return C0114h.m438a(context, str, bundle);
    }

    public abstract View mo42a(int i);

    public abstract boolean mo43a();
}
