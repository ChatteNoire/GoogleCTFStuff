package android.support.v4.p017h;

public interface C0296h {
    void stopNestedScroll();
}
