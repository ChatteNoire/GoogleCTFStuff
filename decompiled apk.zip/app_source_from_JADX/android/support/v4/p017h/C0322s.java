package android.support.v4.p017h;

import android.view.View;

public interface C0322s {
    void mo155a(View view);

    void mo156b(View view);

    void mo157c(View view);
}
