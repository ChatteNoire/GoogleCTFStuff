package android.support.v4.p017h;

import android.view.View;

public interface C0302n {
    C0327v mo317a(View view, C0327v c0327v);
}
