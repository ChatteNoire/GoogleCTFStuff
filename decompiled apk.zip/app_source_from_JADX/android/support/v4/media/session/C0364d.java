package android.support.v4.media.session;

import android.media.session.MediaSession.QueueItem;

class C0364d {

    static class C0363a {
        public static Object m1694a(Object obj) {
            return ((QueueItem) obj).getDescription();
        }

        public static long m1695b(Object obj) {
            return ((QueueItem) obj).getQueueId();
        }
    }
}
