package android.support.constraint.p007a;

import android.support.constraint.p007a.C0072f.C0070a;
import android.support.constraint.p007a.C0072f.C0071b;

public class C0067c {
    C0070a<C0066b> f364a = new C0071b(256);
    C0070a<C0074g> f365b = new C0071b(256);
    C0074g[] f366c = new C0074g[32];
}
