package android.support.v7.view.menu;

import android.widget.ListView;

public interface C0515s {
    void mo412a();

    void mo419c();

    boolean mo422d();

    ListView mo423e();
}
