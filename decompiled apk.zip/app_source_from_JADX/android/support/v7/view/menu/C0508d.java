package android.support.v7.view.menu;

class C0508d<T> {
    final T f1569b;

    C0508d(T t) {
        if (t == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.f1569b = t;
    }
}
