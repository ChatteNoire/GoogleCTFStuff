package android.support.v7.widget;

import android.support.v7.view.menu.C0506o.C0459a;
import android.view.Menu;
import android.view.Window.Callback;

public interface ac {
    void mo454a(int i);

    void mo455a(Menu menu, C0459a c0459a);

    boolean mo456e();

    boolean mo457f();

    boolean mo458g();

    boolean mo459h();

    boolean mo460i();

    void mo461j();

    void mo462k();

    void setWindowCallback(Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
