package android.support.v7.widget;

import android.graphics.Rect;

public interface ag {

    public interface C0452a {
        void mo318a(Rect rect);
    }

    void setOnFitSystemWindowsListener(C0452a c0452a);
}
